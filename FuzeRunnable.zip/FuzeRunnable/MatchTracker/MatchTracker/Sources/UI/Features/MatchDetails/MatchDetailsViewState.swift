//
//  MatchesDetailsViewState.swift
//  MatchTracker
//
//

import Foundation

enum MatchDetailsViewState {
    case loading
    case success
    case error(Error)
}
