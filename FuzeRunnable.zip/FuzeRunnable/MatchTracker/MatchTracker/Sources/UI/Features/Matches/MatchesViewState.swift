//
//  MatchesViewState.swift
//  MatchTracker
//
//

import Foundation

enum MatchesViewState {
    case loading
    case success
    case error(Error)
}
